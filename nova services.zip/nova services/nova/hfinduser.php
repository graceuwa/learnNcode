<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update User</title>
</head>
<body>
	<?php
	$userName = $_POST['userName'];
	$password = $_POST['password'];
	$status = $_POST['status'];
	$priority = $_POST['priority'];
	include('connection.php');
	$sql1 = "UPDATE users SET Password = '$password', Priority = '$priority', Status = '$status', Date = now(),  User = '$username' WHERE UserName = '$userName'";
	$que1 = mysqli_query($con,$sql1);
	if($que1){
    	echo"<script>alert('User Successfullly Updated')</script>";
	}else{
    	echo"Error Updating User".mysqli_error($con);
	}
	mysqli_close($con);
	?>
</body>
</body>
</html>