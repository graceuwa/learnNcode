<div class="container">

	<form class="myform" action="training.php" method="post">
		<h2>Change required Fields. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Training Code (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" class="read" name="trainingCode" readonly="" value="<?php echo $TrainingCode; ?>">
		</div>
		<div class="forminput">
			<label>Title (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" class="read" name="title" value="<?php echo $Title; ?>">
		</div>
		
		<div class="forminput">
			<label>Description (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="description" class="read" value="<?php echo $Description; ?>" >
		</div>
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="status" required="">
				<option><?php echo $Status; ?></option>
				<?php 
				if($Status == "Active")
				{
					?>
					<option value="Inactive">Inactive</option>
					<?php
				}
				else{
					?>
					<option value="Active">Active</option>
					<?php
				}
				?>
				
			</select>
		</div>
		<div class="forminput">
			<label>Price (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="number" name="price" required="" min="1" value="<?php echo $Price; ?>">
		</div>
		<div class="forminput">
			<label>Start Date </label>
			<input type="date" name="startDate" value="<?php echo $StartDate; ?>">
		</div>
		<div class="forminput">
			<label>End Date </label>
			<input type="date" name="endDate" value="<?php echo $EndDate; ?>">
		</div>
		<input type="hidden" class="read" name="trainingId" readonly="" value="<?php echo $TrainingId; ?>">
		<input type="hidden" class="read" name="userId" readonly="" value="<?php echo $UserId; ?>">
		<input class="button" type="submit" name="updateTrainer" value="Update">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="training.php" class="button">Back</a>
	</form>
</div>