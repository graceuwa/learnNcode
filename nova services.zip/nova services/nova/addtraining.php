<div class="container">

	<form class="myform" action="training.php" method="post">
		<h2>Fill in Training's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Training Code (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="trainingCode" required="" placeholder="Enter the training code">
		</div>
		<div class="forminput">
			<label>Title (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="title" required="" placeholder="Enter the training title">
		</div>
		<div class="forminput">
			<label>Description (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="description" required="" placeholder="Enter training Description">
		</div>
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="status" required="">
				<option>Active</option>
				<option>Inactive</option>
			</select>
		</div>
		<div class="forminput">
			<label>Price (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="number" name="price" required="" min="1" placeholder="price in Frw">
		</div>
		<div class="forminput">
			<label>Start Date</label>
			<input type="date" name="startDate" placeholder="Starting date">
		</div>
		<div class="forminput">
			<label>End date</label>
			<input type="date" name="endDate" placeholder="Ending date">
		</div>
		<input class="button" type="submit" name="saveTraining" value="Save">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="training.php" class="button">Back</a>
	</form>
</div>