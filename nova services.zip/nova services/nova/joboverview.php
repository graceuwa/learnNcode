<!-- <!DOCTYPE html>
<html>
<head -->>
	<<!-- title>About CTC Jobs</title>
	<style type="text/css">
		*{
			margin: 0;
			padding: 0;
			box-sizing: border-box;
		}
		body{
			background: url('images/bank4.jpg') no-repeat;
			background-size: cover;
			background-position: center;
			margin: 0;
			padding: 0;
		}
		.container{
			width: 60%;
			margin: auto;
			margin-top: 15px;
			background-color: rgba(0,0,0,0.5);
			background-size: cover;
			border: 1px solid #ccc;
			padding: 10px;
			transition: 0.5s;
		}
		.container .head1.chh2{
			text-align: center;
			font-family: sans-serif;
			color: #ff8c00;
			font-weight: bold;
			margin-bottom: 15px;
			animation: textanimation2 0.5s ease-in-out;
		}
		@keyframes textanimation2 {
		    0% {
		        transform: scale(0);
		    }
		    100% {
		        transform: scale(1);
		    }
		}
		h2{
			font-family: sans-serif;
			color: #ff8c00;
			font-weight: bold;
			margin-bottom: 15px;
		}
		p{
			color: #fff;
			margin-bottom: 15px;
			/*font-size: 18px;*/
			line-height: 1.6em;
			font-family: sans-serif;
			text-align: justify;
		}
		ul{
			margin-left: 40px;
		}
		ul li{
			color: #fff;
			line-height: 1.6em;
		}
		.ch2{
		    /*text-align: center;*/
		    /*font-size: 80px;*/
		    /*color: #fff;*/
		    /*font-weight: bold;*/
		    animation: textanimation 1s ease-in-out;
		}

		@keyframes textanimation {
		    0% {
		        letter-spacing: 20px;
		    }
		    100% {
		        letter-spacing: 1px;
		    }
		}
	</style>
</head>
<body>
	<div class="container">
		<h2 class="head1 chh2" >About ClearTrust Consulting Jobs</h2>
		<di -->v class="info">
			<p style="font-weight: bold;font-size: 20px; color: #cd7f32;">Become part of an unbeatable team of <!-- legal, compliance,business, finance and accounting experts
			</p>
			<p>We are continuously on the lookout for talents to enhance our pool of experts in the financial sector. Do you have a particular expertise or do you have an exceptional interest in financial industry or a combination of both? Apply on suitable open positions hereafter advertized.</p>
			<p>If you are in search for a new job but you did not find what you were looking for under current openings, please note that due to request of some of our clients we do not always advertise all of the positions we are working on. You may send us a spontaneous candidacy at <span style="color: #96CA1E;">info@cleartrustconsulting.com</span> </p>
			<p>Should you like to receive professional advice regarding your career, current market trends, more information about upcoming job opportunities or possibilities to sharpen your knowledge through our market-oriented professional trainings, please contact us using <span style="color: #96CA1E;">info@cleartrustconsulting.com</span> </p>
			<p>We will be happy  to revert to you and speak with you on the phone or organize a quick meeting in our office in Luxembourg or in Brussels to learn more about your career objectives.</p>
		</div>
	</div>
</body>
</html> -->