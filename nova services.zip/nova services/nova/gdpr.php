<!DOCTYPE html>
<html>
<head>
	<title>GDPR</title>
		<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
	<div class="container">
		<h2>GDPR (General Data Protection Regulation)</h2>
		<p> 
			As of May 2018, with the entry into application of the General Data Protection Regulation, there is one set of data protection rules for all companies operating in the EU, wherever they are based.
		</p>
		<p>
			The General Data Protection Regulation (GDPR) applies to the processing of personal data wholly or partly by automated means as well as to non-automated processing. Our training provides full knowledge of this regulation. 
		</p>
		<p>
			At the end of the training, candidates will be able to perform  this processing which covers a wide range of operations performed on personal data, including by manual or automated means. It includes the collection, recording, organisation, structuring, storage, adaptation or alteration, retrieval, consultation, use, disclosure by transmission, dissemination or otherwise making available, alignment or combination, restriction, erasure or destruction of personal data.
		</p>
		<p>
			Our trained candidates will be fit and ready to help companies implement GDPR and comply with it.
		</p>
		<a class="button" href="readtraining1.html">Go Back</a>
	</div>
</body>
</html>