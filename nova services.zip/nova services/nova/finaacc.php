<!DOCTYPE html>
<html>
<head>
	<title>Finance Accounting</title>
			<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
<div class="container">
	<h2>Finance and Accountancy</h2>
	<p>In this training, you will be introduced to the terminology of both topics and familiarized with the basics as well as some advanced concepts and theories. Courses are market oriented. This means that relevance and applicability to your job are at their core. All courses consist of highly interactive.</p>
	<a class="button" href="readtraining1.html">Go Back</a>
</div>
</body>
</html>