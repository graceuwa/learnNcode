
<div class="container">

	<form class="myform" action="trainee.php" method="post">
		<h2>Edit Trainee's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="firstName" required="" placeholder="Enter the first name"  value="<?php echo $firstName;?>">
		</div>
		<div class="forminput">
			<label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="lastName" required="" placeholder="Enter the last name" value="<?php echo $LastName;?>">
		</div>
		<div class="forminput">
			<label>Gender (<span style="color: red; font-size: 20px;">*</span>)</label>
			<?php 
			if($gender == "Male"){
				?>
				<input type="radio" name="gender" required="" value="Male" checked="">Male
				<input type="radio" name="gender" required="" value="Female">Female
				<?php 
			}else{
				?>
				<input type="radio" name="gender" required="" value="Male">Male
				<input type="radio" name="gender" required="" value="Female" checked="">Female
				<?php 
			}
			?>
			
		</div>
		<div class="forminput">
			<label>DoB (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="date" name="dob" required="" value="<?php echo $dateOfBirth;?>">
		</div>
		<div class="forminput">
			<label>Job title </label>
			<input type="text" name="jobTite" placeholder="Enter the job title" value="<?php echo $jobTitle;?>">
		</div>
		<div class="forminput">
			<label>Education Level (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="educationLevel" required="">
				<option value="">--select level--</option>
				<?php 
				if($educationLevel == "O Level"){
					?>
					<option value="O Level" selected="">O Level</option>
					<?php 
				}else{
					?>
					<option value="O Level">O Level</option>
					<?php 
				}
				?>
				
				<?php 
				if($educationLevel == "A Level"){
					?>
					<option value="A Level" selected="">A Level</option>
					<?php 
				}else{
					?>
					<option value="A Level">A Level</option>
					<?php 
				}
				?>

				<?php 
				if($educationLevel == "Diploma"){
					?>
					<option value="Diploma" selected="">Diploma</option>
					<?php 
				}else{
					?>
					<option value="Diploma">Diploma</option>
					<?php 
				}
				?>
				
				<?php 
				if($educationLevel == "Bachelor"){
					?>
					<option value="Bachelor" selected="">Bachelor's Degree(A0)</option>
					<?php 
				}else{
					?>
					<option value="Bachelor">Bachelor's Degree(A0)</option>
					<?php 
				}
				?>

				<?php 
				if($educationLevel == "Post Graduate Diploma"){
					?>
					<option value="Post Graduate Diploma" selected="">Post Graduate Diploma</option>
					<?php 
				}else{
					?>
					<option value="Post Graduate Diploma">Post Graduate Diploma</option>
					<?php 
				}
				?>

				<?php 
				if($educationLevel == "Master"){
					?>
					<option value="Master" selected="">Master's Degree</option>
					<?php 
				}else{
					?>
					<option value="Master">Master's Degree</option>
					<?php 
				}
				?>

				<?php 
				if($educationLevel == "PhD"){
					?>
					<option value="PhD" selected="">PhD</option>
					<?php 
				}else{
					?>
					<option value="PhD">PhD</option>
					<?php 
				}
				?>
			</select>
		</div>
		<div class="forminput">
			<label>Phone number (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" maxlength="10" name="phoneNumber" required="" placeholder="Enter the phone number 078####### / 079####### / 072####### /073#######" onkeypress="return (event.charCode <= 31 || (event.charCode >= 48 && event.charCode <= 57))" pattern="[0][7][8/9/2/3][0-9]{7}" value="<?php echo $mobilePhone;?>">
		</div>
		<div class="forminput">
			<label>Email (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="email" name="email" required="" placeholder="Enter the email" value="<?php echo $email;?>">
		</div>
		<div class="forminput">
			<label>Country (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="county" required="" placeholder="Enter the country" value="<?php echo $country;?>">
		</div>
		<div class="forminput">
			<label>District (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="district" required="" placeholder="Enter the district" value="<?php echo $district;?>">
		</div>
		<input type="hidden" name="traineeId" value="<?php echo $traineeId; ?>">
		<input class="button" type="submit" name="editTrainee" value="Update">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="trainee.php" class="button">Back</a>
	</form>
</div>
