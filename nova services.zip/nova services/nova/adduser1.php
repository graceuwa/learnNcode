<div class="container">

	<form class="myform" action="user.php" method="post">
		<h2>Fill in user's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="firstName" required="" placeholder="Enter the first name">
		</div>
		<div class="forminput">
			<label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="lastName" required="" placeholder="Enter the last name">
		</div>
		<div class="forminput">
			<label>Nationality (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="nationality" required="" placeholder="Enter the nationality">
		</div>
		<div class="forminput">
			<label>Address (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="address" required="" placeholder="Enter the address">
		</div>
		<div class="forminput">
			<label>Phone number (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="phoneNumber" required="" placeholder="Enter the phone number 078####### / 079####### / 072####### /073#######" onkeypress="return (event.charCode <= 31 || (event.charCode >= 48 && event.charCode <= 57))" pattern="[0][7][8/9/2/3][0-9]{7}">
		</div>
		<div class="forminput">
			<label>Email (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="email" name="email" required="" placeholder="Enter the email">
		</div>
		<div class="forminput">
			<label>Qualification (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="qualification" required="">
				<option value="">--select qualification--</option>
				<option value="Diploma">Diploma(A1)</option>
				<option value="Bachelor">Bachelor's Degree(A0)</option>
				<option value="Post Graduate Diploma">Post Graduate Diploma</option>
				<option value="Master">Master's Degree</option>
				<option value="PhD">PhD</option>
			</select>
		</div>
		<div class="forminput">
			<label>Domain (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="domain" required="" placeholder="Enter the domain">
		</div>
		<input class="button" type="submit" name="saveTrainer" value="Save">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="trainer.php" class="button">Back</a>
	</form>
</div>
