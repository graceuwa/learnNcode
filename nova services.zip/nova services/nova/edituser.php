<div class="container">

	<form class="myform" action="user.php" method="post">
		<h2>Editing user... </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="firstName" required="" placeholder="Enter the first name" value="<?php echo $FirstName;?>">
		</div>
		<div class="forminput">
			<label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="lastName" required="" placeholder="Enter the last name" value="<?php echo $LastName;?>">
		</div>
		<div class="forminput">
			<label>UserName (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="UserName" required="" placeholder="Enter the UserName" value="<?php echo $UserName;?>">
		</div>
		<div class="forminput">
			<label>Password (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="Password" required="" placeholder="Enter the Password" value="<?php echo $Password;?>">
		</div>
		 <div class="forminput">
			<label>Priority (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="Priority" required="">
				<option value="">--please select--</option>
				<?php 
				if($Priority == "Admin"){
					?>
					<option value="Admin" selected="">Admin</option>
					<?php 
				}else{
					?>
					<option value="Admin">Admin</option>
					<?php 
				}
				?>

				<?php

				if($Priority == "Trainee"){
					?>
					<option value="Trainee" selected="">Trainee</option>
					<?php 
				}else{
					?>
					<option value="Trainee">Trainee</option>
					<?php 
				}
				?>
				
				
			</select>
		</div> 
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			 <select name="status" required="">
			 	<option value="">--please select--</option>
			 	<?php 
			 	if($Status == "Active"){
			 		?>
			 		<option value="Active" selected="">Active</option>
			 		<?php 
			 	}else{
			 		?>
			 		<option value="Active">Active</option>
			 		<?php 
			 	}
			 	?>
				
				<?php 
			 	if($Status == "Inactive"){
			 		?>
			 		<option value="Inactive" selected="">Inactive</option>
			 		<?php 
			 	}else{
			 		?>
			 		<option value="Inactive">Inactive</option>
			 		<?php 
			 	}
			 	?>
				
			</select>
		</div>
		<input type="hidden" name="userId" value="<?php echo $UserId;?>" >
		<input class="button" type="submit" name="updateuser" value="Update">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="user.php" class="button">Back</a>
	</form>
</div>

