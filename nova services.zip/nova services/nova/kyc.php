<!DOCTYPE html>
<html>
<head>
	<title>KCY</title>
	<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
	<div class="container">
		<h2>know your customer or know your client (KYC) </h2>
		<p>The know your customer or know your client (KYC) guidelines in financial services requires that professionals make an effort to verify the identity, suitability, and risks involved with maintaining a business relationship. KYC processes are employed by companies for the purpose of ensuring their proposed customers, agents, consultants, or distributors are anti-money laundering, anti-bribery compliant, and are actually who they claim to be. Banks, insurers, investments funds, export creditors and other financial institutions are increasingly demanding that customers provide detailed due diligence information according to legal requirements.</p>
		<p>To stay on the right side, every company needs to know its customers and verify their identities. The process of identification and verification of the customer's identity and business within the company is mandatory.</p>
		<p>For example:</p>
		<ul>
		<li>When opening an account( Identification of a person)</li> 
		<li>Conducting transactions with their customers.</li>
		<li>Analyses new customer processes and policies</li>
		<li>Review documentation for new customers’ accounts.</li>
		</ul>
		<p>This training aims at providing suitable knowledge and the practice with software used in financial sector to help  financial institutions  fulfil their obligations.</p>
		<a class="button" href="readtraining1.html">Go Back</a>
</div>
</body>
</html>