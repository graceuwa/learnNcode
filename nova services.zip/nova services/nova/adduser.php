<div class="container">

	<form class="myform" action="user.php" method="post">
		<h2>Fill in user's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="firstName" required="" placeholder="Enter the first name">
		</div>
		<div class="forminput">
			<label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="lastName" required="" placeholder="Enter the last name">
		</div>
		<div class="forminput">
			<label>UserName (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="UserName" required="" placeholder="Enter the UserName">
		</div>
		<div class="forminput">
			<label>Password (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="Password" required="" placeholder="Enter the Password">
		</div>
		 <div class="forminput">
			<label>Priority (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="Priority" required="">
				<option value="">--please select--</option>
				<option value="Admin">Admin</option>
				<option value="Trainee">Trainee</option>
			</select>
		</div> 
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			 <select name="status" required="">
			 	<option value="">--please select--</option>
				<option value="Active">Active</option>
				<option value="Inactive">Inactive</option>
			</select>
		</div>
		<!-- <div class="forminput">
			<label>Qualification (<span style="color: red; font-size: 20px;">*</span>)</label>
			select name="qualification" required="">
				<option value="">--select qualification--</option>
				<option value="Diploma">Diploma(A1)</option>
				<option value="Bachelor">Bachelor's Degree(A0)</option>
				<option value="Post Graduate Diploma">Post Graduate Diploma</option>
				<option value="Master">Master's Degree</option>
				<option value="PhD">PhD</option>
			</select> -->
		<!-- </div>
		<div class="forminput">
			<label>Domain (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="domain" required="" placeholder="Enter the domain">
		</div> -->
		<input class="button" type="submit" name="saveuser" value="Save">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<a href="user.php" class="button">Back</a>
	</form>
</div>

