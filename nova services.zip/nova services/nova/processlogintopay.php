<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<?php
if(isset($_POST['login']))
{
 if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
$_SESSION["usernamepay"] = "";
$_SESSION["passwordpay"] = "";
$_SESSION["fname"] = "";
$_SESSION["lname"] = "";
$userName = "";
$password="";
include('connection.php');
$userName = prepare_input($_POST['userName']);
$password = prepare_input($_POST['password']);
$password = sha1($password);
$sql = "select * from users where UserName='$userName' and Password='$password'";
$que1= mysqli_query($con,$sql);
if($que1){
	$num=mysqli_num_rows($que1);
	if($num){
		$tab = mysqli_fetch_array($que1);
		$fanme = $tab['FirstName'];
		$lanme = $tab['LastName'];
		$traineeName = $fanme ." ". $lanme;
		// $id = $tab['Id'];
		// $_SESSION["usernamepay"] = $userName;
		// $_SESSION["passwordpay"] = $password;
		// $_SESSION["fname"] = $fanme;
		// $_SESSION["lname"] = $lanme;
        // echo"<script>alert('Welcome $fanme $lanme ')</script>";
		// header('Location: methodtopay.php');
		// exit;
		echo '<div id="printdiv" class="container"><table border="1" class="table table-bordered" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0">
		<tr><td colspan="5"><center>Selected Trainings</center></td></tr>
		<tr><td colspan="5"><center>Selected by: '.$traineeName.' </center></td></tr>

		<tr><th>#</th><th>Course</th><th>Start Date</th><th>End Date</th><th>Amount</th></tr>';
		$courses = $_SESSION['courses'];
		$total_amount =$_SESSION['totalamount'];
		$i=1;
		// echo"my courses. " . $courses;
		// exit;
		foreach($courses as $index=>$value)
		{
		$sqlc = "select * from training where Title ='$value'";
		$quec= mysqli_query($con,$sqlc);
		$tabc = mysqli_fetch_array($quec);
		$Price = $tabc['Price'];
		$StartDate = $tabc['StartDate'];
		$EndDate = $tabc['EndDate'];
		echo "<tr><td>$i</td>";
		echo "<td>$value</td>";
		echo "<td>$StartDate</td>";
		echo "<td>$EndDate</td>";
		echo "<td>$Price</td>";
		echo "</tr>";
		$i+=1;
		}
		echo "<tr><td colspan=4>Total</td><td>$total_amount</td></tr>
		<tr><td colspan=5>Account Number: 4400180352</td></tr>
		<tr><td colspan=5>Account Name: NOVA Services Ltd</td></tr>
		<tr><td colspan=5>Bank Name: BPR</td></tr>
		</table></div>";
		echo"<center>
			<button class=\"printbtn\" onclick=\"printContent('printdiv')\">Print</button>
		</center>";
	}
	else{
        echo"<script>alert('Incorrect Username/Password. Try again!')</script>";
        include("logintopay.php");
	}
}
else{
	echo"Error ".mysqli_error($que1);
}
}
?>
<script>
function printContent(el){
		
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();
		document.body.innerHTML = restorepage;
		window.location.reload(true);
}
</script>