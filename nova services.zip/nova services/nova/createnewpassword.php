<!DOCTYPE html>
<html>
<head>
	<title>Create new password</title>
</head>
<body>
	<div class="container">
	<?php
	$selector = $_GET["selector"];
	$validator = $_GET["validator"];
	if(empty($selector)||empty($validator)){
		echo"Could not validate your request";
	}
	else{
		if(ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false){
			?>
			<form class="myform" action="resetpasswordh.php" method="post">
		<h2>Fill in Staff's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<input type="hidden" readonly="" name="selector" value="<?php echo $selector;?>">
		</div>
		<div class="forminput">
			<input type="hidden" readonly="" name="validator" value="<?php echo $validator;?>">
		</div>
		<div class="forminput">
			<label>Password (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="password" name="pwd" required="" placeholder="Enter a new password">
		</div>
		<div class="forminput">
			<label>Repeat Password (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="password" name="pwdRepeat" required="" placeholder="Repeat new password">
		</div>
		<input class="button" type="submit" name="reset-password-submit" value="Reset Password">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
			<?php
		}
	}
	?>
</div>
</body>
</html>