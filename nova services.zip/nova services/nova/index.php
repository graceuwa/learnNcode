<!DOCTYPE html>
<html>
<head>

	<title>NOVA</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<nav class="navbar">
	<div class="logo">
		<img src="images/logo11.PNG">
		
	</div>
	<div class="nav">
		<ul class="navbar-nav">
			<li><a  href="index.php">Home</a></li>
			<li><a  href="about.html" target="fr">About Us</a></li>
			<li><a href="readconsulting.html" target="fr">Services</a></li>
			<li><a href="register.php" target="fr">Register</a></li>
			<li><a  href="store.php" target="fr">Trainings</a></li>
			
			<li><a  href="contact.html" target="fr">Contact</a></li>
			<li><a href="login.php">Admin</a></li>
		</ul>
	</div>
	<div class="slide">
		<span class="open-slide">
			<a href="#" onclick="openSlideMenu()">
				<svg width="30" height="30">
					<path d="M0,5 30,5" stroke="#fff" stroke-width="5"/>
					<path d="M0,14 30,14" stroke="#fff" stroke-width="5"/>
					<path d="M0,23 30,23" stroke="#fff" stroke-width="5"/>
				</svg>
			</a>
		</span>
	</div>
</nav>
<div id="side-menu" class="side-nav">
	<ul>
		<li><a class="btn-close" href="#" onclick="closeSlideMenu()">&times;</a></li>
		<li><a href="index.html">Home</a></li>
		<li><a href="about.html" target="fr">About Us</a></li>
		<li><a href="#" target="fr">Services</a>
			<div class="submenu1a">
				<ul>
					<li><a href="readconsulting.html" target="fr">nova</a></li>
					<li><a href="readtraining.html" target="fr">Training</a></li>
				</ul>
			</div>
		</li>
		<li><a href="careers.html" target="fr">Careers</a></li>
		<li><a href="ourpeople.html" target="fr">Our People</a></li>
		<li><a href="contact.html" target="fr">Contact</a></li>
	</ul>
</div>
<div id="main">
	<iframe src="slides.html" name="fr">
	</iframe>
</div>
<footer id="main-footer">
	<p>Copyright &copy;2022 <span class="copyr1">NOVA Services Ltd</span><span class="copyr2">Your Key to Professional Trainings</span></p>
</footer>
<script>
	function openSlideMenu(){
		document.getElementById('side-menu').style.width='250px';
		document.getElementById('main').style.marginRight='250px';
	}
	function closeSlideMenu(){
		document.getElementById('side-menu').style.width='0';
		document.getElementById('main').style.marginLeft='0';
	}
</script>
</body>
</html>