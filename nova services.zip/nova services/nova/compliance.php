<!DOCTYPE html>
<html>
<head>
	<title>Compliance</title>
	<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
	<div class="container">
		<h2>Financial compliance</h2>
		<p>Financial compliance is the regulation and enforcement of the laws and rules in finance and the capital markets. It ranges through the entire financial spectrum, from investment banking practices to retail banking practices. This obligation concerns not nonly banks but also  all actors  the financial sector: insurance companies, funds,..</p>
		<p>After our training, candidates will be sufficiently ready to assess financial risks and create procedures and plans to handle those potential issues. They will learn how  to  provide regular reports on the effectiveness of a business's compliance measures how to advise business leadership on any actions or changes that should be implemented.</p>
		<p>The professionals in the financial sector are required to implement the compliance framework to ensure that the company respects laws and regulations. They must keep updated with current regulations and adapt businesses accordingly.</p> 
		<p>For example:</p>
		<ul>
			<li>Provide advice to the business</li>
			<li>Able to interpret the situation on spot very precisely,</li>
			<li>Help people in reaching the right judgement in those frameworks.</li>
		</ul>
		<a class="button" href="readtraining1.html">Go Back</a>
	</div>

</body>
</html>