<!DOCTYPE html>
<html>
    <head>
        <title>Trainings</title>
        <meta name="description" content="This is the description">
        <link rel="stylesheet" href="styles.css" />
        <script src="store.js" async></script>
    </head>
    <body>
        <?php
include('connection.php');
$sql = "SELECT * FROM training WHERE Status = 'Active'";
$que1= mysqli_query($con,$sql);
if($que1){
        $num = mysqli_num_rows($que1);
        if($num){
            ?>
            <section class="container content-section">
            <h2 class="section-header" style="font-family: sans-serif; font-weight: bold;">Trainings</h2>
            <?php
            while($tab = mysqli_fetch_array($que1)){
                $id =$tab['TrainingId'];
                $trainingId =$tab['TrainingId'];
                $title =$tab['Title'];
                $description =$tab['Description'];
                $startDate = $tab['StartDate'];
                $endDate = $tab['EndDate'];
                $price =$tab['Price'];
                $date =$tab['RegDate'];

                // if($startDate == "0000-00-00"){
                //     $startDate = "";
                // }
                // if($endDate == "0000-00-00"){
                //     $endDate = "";
                // }

           
?>
        
            <div class="shop-items">
                <div class="shop-item">
                    <span class="shop-item-title"><?php echo $title; ?></span>
                    <p class="shop-item-image"><?php echo $description; ?></p>
                    <?php 
                    if($startDate != "0000-00-00"){
                    ?>
                    <p class="shop-item-image">Start Date: <?php echo $startDate; ?></p>
                    <?php 
                }
                    ?>

                    <?php 
                    if($endDate != "0000-00-00"){
                    ?>
                    <p class="shop-item-image">End Date: <?php echo $endDate; ?></p>
                    <?php 
                }
                    ?>
                     
                     
                    <div class="shop-item-details">
                        <span class="shop-item-price">Frw<?php echo $price; ?></span><!-- <br> -->
                        <!-- <span class="">$<?php //echo $date; ?></span> -->
                        <button class="btn btn-primary shop-item-button" type="button">Add to Cart</button>
                    </div>
                </div>
            </div>
            <?php
             }
             ?>
        </section>
<?php

        }
}
?>
        <section class="container content-section">
            <!-- <form action="paypage/index.php" method="post"> -->
            <form action="logintopay.php" method="post">
            <h2 class="section-header" style="font-family: sans-serif; font-weight: bold;">CART</h2>
            <div class="cart-row">
                <span class="cart-item cart-header cart-column">Course</span>
                <span class="cart-price cart-header cart-column">Price</span>
                <span class="cart-quantity cart-header cart-column">Action</span>
            </div>
            <div class="cart-items">
            </div>
            <div class="cart-total">
                <strong class="cart-total-title">Total</strong>
                <!-- <span class="cart-total-price">$0</span> -->
                <input type="text" name="totalamount" class="cart-total-price" value="Frw0"> 
            </div>
            <!-- <input class="btn btn-primary btn-purchase" type="submit" value="Proceed to Payment"> -->
            <input  type="submit" name="submitpayment" class="btn btn-primary btn-purchase" value="Proceed to Payment">
            </form>
        </section>
    </body>
</html>