<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Find Training</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
include('connection.php');
	$sql1 = "SELECT * FROM training ORDER BY RegDate";
	$que1 = mysqli_query($con,$sql1);
?>
<div class="container">

	<form class="myform" action="findtraining.php" method="post">
		<h2>Find Training to update. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Select Training (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="trainingId" required="">
				<?php
				while($row = mysqli_fetch_array($que1)){
					$trainingId = $row['TrainingId'];
					$trainingCode = $row['TrainingCode'];
					$trainingTitle = $row['Title'];
					$training = $trainingCode. "-" . $trainingTitle;
					?>
					<option value="<?php echo $trainingId; ?>">
						<?php echo $training; ?></option>
					<?php
				}
				?>
			</select>
			
		</div>
		<input class="button" type="submit" name="find" value="Find">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>