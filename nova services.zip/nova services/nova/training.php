<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $userId = $_SESSION["userId"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Training</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style type="text/css">
#body{
  background: url('images/training1.jpg') no-repeat;
  background-size: cover;
	background-position: center center;
	margin: 0;
	padding: 0;
}
		#myInput{
			width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
	}
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}

table{ table-layout:auto;}
@page    {
  size: auto;  
  margin: 20px;  
 }
table,tr,th,td{border-spacing:0px;
  border-collapse:collapse;
  margin:0px;
  padding:7px;
  word-wrap: break-word;}
  table { page-break-after:auto }
  tr    { page-break-inside:avoid;page-break-after:auto }
  td    { page-break-inside:auto; page-break-after:auto }
caption{
    font-weight: bold;
}

	</style>
</head>
<body style="margin: 20px;" id="body">
	<center>
	<?php
include('connection.php');
if(isset($_GET['action']) && $_GET['action'] == "add"){
	include('addtraining.php');
}else if(isset($_POST['saveTraining'])){
	$trainingCode=$_POST['trainingCode'];
	$title=$_POST['title'];
	$description=$_POST['description'];
	$status=$_POST['status'];
	$price=$_POST['price'];
	$startDate=$_POST['startDate'];
	$endDate=$_POST['endDate'];
	$today = date("Y-m-d");
	if(($startDate != "" && $startDate < $today) || ($endDate != "" && $endDate < $today)){
		echo"<script>alert('Start date and End date cannot be previous dates')</script>";
		echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else if($endDate < $startDate){
		echo"<script>alert('End date cannot be less than Start date')</script>";
		echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else if($status == "Active" && ($startDate == "" || $endDate == "")){
		echo"<script>alert('Active Trainings need start date and end date')</script>";
		echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else{
	$sql = "insert into training(`TrainingCode`,`Title`,`Description`,`Status`,`Price`,`StartDate`,`EndDate`,`RegDate`,`UserId`) values('$trainingCode','$title','$description','$status','$price','$startDate','$endDate',now(),'$userId')";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Training Added Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else{
    	echo"Error Adding Training".mysqli_error($con);
	}
	}
}else if(isset($_GET['action']) && $_GET['action'] == "edit"){
	$trainingId = $_GET['edit'];
	$sql = "SELECT * FROM training WHERE TrainingId = '$trainingId'";
	$que1= mysqli_query($con,$sql);
	$row = mysqli_fetch_array($que1);
	extract($row);
	include('edittraining.php');

}else if(isset($_POST['updateTrainer'])){
	$trainingId = prepare_input($_POST['trainingId']);
	$trainingTitle = prepare_input($_POST['title']);
	$trainingDescription = prepare_input($_POST['description']);
	$price = prepare_input($_POST['price']);
	$status = prepare_input($_POST['status']);
	$startDate = prepare_input($_POST['startDate']);
	$endDate = prepare_input($_POST['endDate']);
	$userId = prepare_input($_POST['userId']);

	$sql = "UPDATE training SET Title = '$trainingTitle', Description = '$trainingDescription',  Status = '$status', Price = '$price', StartDate = '$startDate', EndDate = '$endDate', UserId = '$userId' WHERE TrainingId = '$trainingId'";

	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Training Updated Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else{
    	echo"Error Updating Training".mysqli_error($con);
	}

}else if(isset($_GET['action']) && $_GET['action'] == "delete"){
	$trainingId = $_GET['delete'];
	$sql = "delete from training where TrainingId = '$trainingId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Training Deleted Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=training.php'>";
	}else{
    	echo"Error Deleting Training".mysqli_error($con);
	}
} else{
	$sql = "SELECT * FROM training ORDER BY Status, RegDate";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			
				<input type="text" id="myInput" placeholder="Search for training...">
				<a href="training.php?action=add" target="fr" class="btn btn-primary">Add Training</a>
			<div id="printdiv">
				<div><h4 class="text text-info text-center">List of Trainings</h4></div>
			<table border="1" class="table table-bordered" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0">
		<thead>
			<tr><th>#</th><th>Training code</th><th>Title</th><th>Description</th><th >Status</th><th>Price(Frw)</th><th>Start Date</th><th>End Date</th><th>Reg. Date</th><th class="no-print">Perform</th></tr>
		</thead>
		<tbody id="myTable">
			<?php
			$i=1;
			while($row = mysqli_fetch_array($que1)){
				$trainingId = $row['TrainingId'];
				$trainingCode = $row['TrainingCode'];
				$title = $row['Title'];
				$description = $row['Description'];
				$status = $row['Status'];
				if($status == "Active"){
					$status = "Ongoing";
				}
				$price = $row['Price'];
				$startDate = $row['StartDate'];
				$endDate = $row['EndDate'];
				if($startDate == "0000-00-00"){
					$startDate = "";
				}
				if($endDate == "0000-00-00"){
					$endDate = "";
				}
				$date = $row['RegDate'];
				// $user = $row['User'];
				?>
				<!-- <table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0" id="myTable"> -->
			 
				<tr><td>
					<?php echo $i;?></td><td>
				<?php echo $trainingCode;?></td><td>
				<?php echo $title;?></td><td>
				<?php echo $description;?></td><td>
				<?php echo $status;?></td><td>
				<?php echo $price;?></td><td>
				<?php echo $startDate;?></td><td>
				<?php echo $startDate;?></td><td>
				<?php echo $date;?></td>
				<td class="no-print">
					<a href="training.php?action=edit&edit=<?php echo $trainingId;?>" title="Edit Training <?php echo $title;?>">
						<i class="fa fa-pencil-square-o text-dark"></i></a>&nbsp;&nbsp;|&nbsp;&nbsp;<a href="training.php?action=delete&delete=<?php echo $trainingId;?>" title="Delete Training <?php echo $title;?>" onclick="return confirm('Are you sure you want to delete training <?php echo $title;?>?');"><i class="fa fa-minus-circle text-danger"></i></a></td>

				</tr>
			
				<?php
				$i += 1;
			}
			?>
			</tbody></table>
			</div>
			<center>
			<button class="printbtn" onclick="printContent('printdiv')">Print</button>
		</center>
			<?php
			// exit;
		}
		else{
        	echo'<a href="training.php?action=add" target="fr" class="btn btn-primary">Add Training</a>';
        	echo'<p class="text text-danger">No Trainings Found</p>';
		}
}
else{
	echo"Cannot Display".mysqli_error($con);
}
}
?>

</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
function printContent(el){
		// let nop = document.querySelectorAll('.no-print').style.display = 'none';
		let nop = document.querySelectorAll('.no-print');
		let body = document.getElementById('body');

		for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'none';
		}
		body.style.backgroundImage = "url('white.jpg')";
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();

    for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'block';
		}
		document.body.innerHTML = restorepage;
		window.location.reload(true);
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>

  <script>

$("#myInput").on("keyup",function(){
        var value = $(this).val().toLowerCase();
        //location.reload(true);

        $("#myTable tr").filter(function(){
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });

      });
</script>
</body>
</html>
