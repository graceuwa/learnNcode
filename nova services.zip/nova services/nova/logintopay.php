<?php
 if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
$_SESSION['courses'] = "";
$_SESSION['totalamount'] = "";
$myarray = $_POST;
$myarray1 = array_pop($myarray);
$myarray2 = array_pop($myarray);
$courses ="";
// foreach($myarray as $index=>$value)
// {
// $courses = $courses . $value. ", ";
// }
// $_SESSION['courses'] = $courses;
// $_SESSION['totalamount'] = $myarray2;
$_SESSION['courses'] = $myarray;
$_SESSION['totalamount'] = $myarray2;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login Form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
	<style type="text/css">
		*{
	margin: 0;
	padding: 0;
}
body{
	font-family: sans-serif;
}
.container{
	width: 60%;
	margin: auto;
	margin-top: 200px;
}

.container .logo{
	margin: auto;
	width: 50%;
	height: 140px;
	float: center;
	text-align: center;
}

.container .logo1{
	margin: auto;
	width: 50%;
	height: 140px;
	float: left;
	margin-top: 15px;
	text-align: center;
}

.container .logo2{
	margin: auto;
	width: 50%;
	height: 140px;
	float: right;
	margin-top: 15px;
	text-align: center;
}

/*.container .logocovid{
	width: 40%;
	height: 400px;
	float: right;
}*/

.myform{
	background-color: rgba(0,0,0,0.6);
	border-radius: 15px;
	box-sizing: border-box;
	text-align: center;
}
.myform h2{
	color:#fff;
	margin: 0;
	padding: 0;
	text-align: center;
}
.myform .forminput{
	margin-top:15px;
}
.myform .forminput label{
	display: block;
	color:#fff;
}
.myform .forminput input[type="text"], .myform .forminput input[type="tel"], .myform .forminput input[type="number"], .myform .forminput input[type="password"], .myform .forminput select, .myform .forminput input[type="date"]{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}
.myform .forminput input[type="text"]:focus, .myform .forminput input[type="tel"]:focus, .myform .forminput input[type="number"]:focus, .myform .forminput input[type="password"]:focus, .myform .forminput select:focus, .myform .forminput input[type="date"]:focus {
	width:55%;
	border-color: #2ecc71;
}
.button{
	text-decoration: none;
	background-color: #03a9f4;
	color:#fff;
	padding: 10px 15px;
	border:none;
	margin-top: 10px;
	border-radius: 24px;
	transition: 0.25s;
	outline:none;
	cursor:pointer;
}
.button:hover{
	background-color: green;
}
	</style>
</head>
<body style="background:url(images/login2.jpg) no-repeat;background-size: cover; background-position: center center;">
<div class="container">
	<form class="myform" action="processlogintopay.php" method="post">
		<h2>Login Here To proceed to the payment</h2>
		<div class="forminput">
			<label>User name</label>
			<input type="text" name="userName" required="" placeholder="User email">
		</div>
		<div class="forminput">
			<label>Password</label>
			<input type="password" name="password" required="" placeholder="password">
		</div>
		<input class="button" type="submit" name="login" value="Continue">
		<input class="button" type="reset" name="reset" value="Clear Form">
		<br><br>
		<a class="button" href="resetpassword.php">Forgot your password?</a>
	</form>
</div>
</body>
</html>