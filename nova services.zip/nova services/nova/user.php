<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $userId = $_SESSION["userId"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>users</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style type="text/css">
	#body{
  background: url('images/UserS.jpg') no-repeat;
  background-size: cover;
	background-position: center;
	margin: 0;
	padding: 0;
}
		#myInput{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}

table{ table-layout:auto;}
@page    {
  size: auto;  
  margin: 20px;  
 }
table,tr,th,td{border-spacing:0px;
  border-collapse:collapse;
  margin:0px;
  padding:7px;
  word-wrap: break-word;}
  table { page-break-after:auto }
  tr    { page-break-inside:avoid;page-break-after:auto }
  td    { page-break-inside:auto; page-break-after:auto }
caption{
    font-weight: bold;
}

	</style>
</head>
<body style="margin: 20px;" id="body">
	<center>
	<?php
include('connection.php');
if(isset($_GET['action']) && $_GET['action'] == "add"){
	include('adduser.php');
}else if(isset($_POST['saveuser'])){
	 // $UserId = prepare_input($_POST['UserId']);
	$FirstName = prepare_input($_POST['firstName']);
	$LastName = prepare_input($_POST['lastName']);
	$UserName = prepare_input($_POST['UserName']);
	$Password = prepare_input($_POST['Password']);
	$Password = sha1($Password);
	$Priority = prepare_input($_POST['Priority']);
	$Status = prepare_input($_POST['status']);
	$sql = "insert into users(`FirstName`,`LastName`,`UserName`,`Password`,`Priority`,`Status`) values('$FirstName','$LastName','$UserName','$Password','$Priority','$Status')";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('user Added Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=user.php'>";
	}else{
    	echo"Error Adding user".mysqli_error($con);
	}

	
}else if(isset($_GET['action']) && $_GET['action'] == "edit"){
	$userId = $_GET['edit'];
	$sql = "SELECT * FROM users WHERE userId = " . $userId;
	$que1= mysqli_query($con,$sql);
	$row = mysqli_fetch_array($que1);
	extract($row);
	include('edituser.php');

}else if(isset($_POST['updateuser'])){
	$UserId = prepare_input($_POST['userId']);
	$firstName = prepare_input($_POST['firstName']);
	$lastName = prepare_input($_POST['lastName']);
	$UserName = prepare_input($_POST['UserName']);
	$Password = prepare_input($_POST['Password']);
	$Password = sha1($Password);
	$Priority= prepare_input($_POST['Priority']);
	$Status= prepare_input($_POST['status']);
	// $qualification = prepare_input($_POST['qualification']);
	// $domain = prepare_input($_POST['domain']);

	$sql = "update users set FirstName = '$firstName', LastName = '$lastName', UserName = '$UserName', Password = '$Password', Priority = '$Priority', Status = '$Status' where UserId = '$UserId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('user  Updated Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=user.php'>";
	}else{
    	echo"Error Updating User: ".mysqli_error($con);
	}

}else if(isset($_GET['action']) && $_GET['action'] == "delete"){
	$userId = $_GET['delete'];
	$sql = "delete from users where userId = '$userId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('User Deleted Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=user.php'>";
	}else{
    	echo"Error Deleting user".mysqli_error($con);
	}
} else{
	$sql = "SELECT * FROM users ORDER BY UserId";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			
				<input type="text" id="myInput" placeholder="Search for users...">
				<a href="user.php?action=add" target="fr" class="btn btn-primary">Add user</a>
			<div id="printdiv">
				<div><h4 class="text text-info text-center">List of users</h4></div>
			<table border="1" class="table table-bordered" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0">
		<thead>
			<tr><th>#</th><th>First Name</th><th>Last Name</th><th>UserName</th><th width="15%">Priority</th><th>Status</th><th class="no-print">Perform</th></tr>
		</thead>
		<tbody id="myTable">
			<?php
			$i=1;
			while($row = mysqli_fetch_array($que1)){
				$UserId = $row['UserId'];
				$firstName = $row['FirstName'];
				$lastName = $row['LastName'];
				$fullName = $firstName . " " . $lastName;
				$userName = $row['UserName'];
				$Password= $row['Password'];
				$Priority = $row['Priority'];
				$Status = $row['Status'];
				// $email = $row['Email'];
				// $qualification = $row['Qualification'];
				// $domain = $row['Domain'];
				// $user = $row['User'];
				?>
				<!-- <table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0" id="myTable"> -->
			 
				<tr><td>
				<?php echo $i;?></td><td>
				<?php echo $firstName;?></td><td>
				<?php echo $lastName;?></td><td>
				<?php echo $userName;?></td><td>
				<?php echo $Priority;?></td><td>
				<?php echo $Status;?></td><td class="no-print">
					<a href="user.php?action=edit&edit=<?php echo $UserId;?>" title="Edit user <?php echo $fullName;?>">
						<i class="fa fa-pencil-square-o text-dark"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="user.php?action=delete&delete=<?php echo $UserId;?>" title="Delete user <?php echo $fullName;?>" onclick="return confirm('Are you sure you want to delete user <?php echo $fullName;?>?');"><i class="fa fa-minus-circle text-danger"></i></a></td>

				</tr>
			
				<?php
				$i += 1;
			}
			?>
			</tbody></table>
			</div>
			<center>
			<button class="printbtn" onclick="printContent('printdiv')">Print</button>
		</center>
			<?php
			// exit;
		}
		else{
        	echo'<a href="user.php?action=add" target="fr" class="btn btn-primary">Add user</a>';
        	echo'<p class="text text-danger">No user Found</p>';
		}
}
else{
	echo"Cannot Display:".mysqli_error($con);
}
}
?>

</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
function printContent(el){
		// let nop = document.querySelectorAll('.no-print').style.display = 'none';
		let nop = document.querySelectorAll('.no-print');
		let body = document.getElementById('body');

		for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'none';
		}
		//body.style.backgroundSize= "auto";
		body.style.backgroundImage = "url('white.jpg')";
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();

    for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'block';
		}
		document.body.innerHTML = restorepage;
		window.location.reload(true);
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>

  <script>

$("#myInput").on("keyup",function(){
        var value = $(this).val().toLowerCase();
        //location.reload(true);

        $("#myTable tr").filter(function(){
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });

      });
</script>
</body>
</html>


