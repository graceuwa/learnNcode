<!DOCTYPE html>
<html>
<head>
	<title>Your message</title>
</head>
<body>
<?php
$message_sent = 0;
if(isset($_POST['submit'])){
	$email = $_POST['email'];
	$message = $_POST['message'];
	$to = $email;
	$body = "";
	$body .= "Email".$email."\r\n";
	$body .= "Email".$message."\r\n";
	$messageSubject = "My subject";
	$from = "endagimana@yahoo.com";
	$headers = [ "From: $from" ];
	mail($to, $messageSubject, $body, implode( '\r\n', $headers ));
	$message_sent = 1;
	}
if($message_sent == 1){
	echo"Message sent";
}
?>
</body>
</html>