<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update User</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
$userName = $_POST['userName'];
include('connection.php');
	$sql1 = "SELECT * FROM users WHERE UserName = '$userName'";
	$que1 = mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($que1);
	$password = $row['Password'];
	$priority = $row['Priority'];
	$status = $row['Status'];

?>
<div class="container">

	<form class="myform" action="hfinduser.php" method="post">
		<h2>Change required Fields. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>User Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" class="read" name="userName" readonly="" value="<?php echo $userName; ?>">
		</div>
		<div class="forminput">
			<label>Password (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="password" required="" value="<?php echo $password; ?>">
		</div>
		<div class="forminput">
			<label>Priority (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="priority" required="">
				<option><?php echo $priority; ?></option>
				<?php 
				if($priority == "Admin")
				{
					?>
					<option>Guest</option>
					<?php
				}
				else{
					?>
					<option>Admin</option>
					<?php
				}
				?>
				
			</select>
		</div>
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="status" required="">
				<option><?php echo $status; ?></option>
				<?php 
				if($status == "Active")
				{
					?>
					<option>Inactive</option>
					<?php
				}
				else{
					?>
					<option>Active</option>
					<?php
				}
				?>
				
			</select>
		</div>
		<input class="button" type="submit" name="update" value="Update">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>