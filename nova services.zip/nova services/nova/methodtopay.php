<?php
 if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   if(isset($_POST['continue'])){
   $paymentmethod = $_POST['paymentmethod'];
   if($paymentmethod == "Credit or Debit card"){
   header('Location: paypage/index.php');
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Payment method</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- <link rel="stylesheet" type="text/css" href="style.css"> -->
	<style type="text/css">
		*{
	margin: 0;
	padding: 0;
}
body{
	font-family: sans-serif;
}
.container{
	width: 40%;
	margin: auto;
	margin-top: 250px;
}

.container .logo{
	margin: auto;
	width: 50%;
	height: 140px;
	float: center;
	text-align: center;
}

.container .logo1{
	margin: auto;
	width: 50%;
	height: 140px;
	float: left;
	margin-top: 15px;
	text-align: center;
}

.container .logo2{
	margin: auto;
	width: 50%;
	height: 140px;
	float: right;
	margin-top: 15px;
	text-align: center;
}

/*.container .logocovid{
	width: 40%;
	height: 400px;
	float: right;
}*/

.myform{
	background-color: rgba(0,0,0,0.6);
	border-radius: 15px;
	box-sizing: border-box;
	text-align: center;
}
.myform h2{
	color:#fff;
	margin: 0;
	padding: 0;
	text-align: center;
}
.myform .forminput{
	margin-top:15px;
}
.myform .forminput label{
	display: block;
	color:#fff;
}
.myform .forminput select{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}
.button{
	text-decoration: none;
	background-color: #03a9f4;
	color:#fff;
	padding: 10px 15px;
	border:none;
	margin-top: 10px;
	border-radius: 24px;
	transition: 0.25s;
	outline:none;
	cursor:pointer;
}
.button:hover{
	background-color: green;
}
	</style>
</head>
<body style="background:url(images/login2.jpg) no-repeat;background-size: cover; background-position: center center;">
<div class="container">
	<form class="myform" action="" method="post">
		<h2>Payment method</h2>
		<div class="forminput">
			<label>Select payment method</label>
			<select name="paymentmethod">
				<option value="Credit or Debit card">Credit or Debit card</option>
				<option value="Bank Transfer">Bank Transfer</option>
			</select>
		</div>
		<input class="button" type="submit" name="continue" value="Continue">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>