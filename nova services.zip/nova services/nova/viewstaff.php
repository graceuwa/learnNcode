<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View Staff</title>
<style type="text/css">
table{ table-layout:fixed;}
td{wrappable}
 @page{
  size: auto;  
  margin: 0;  
 }
</style>
<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>
  <style type="text/css">
  table,th,td{border-spacing:0px;
  border-collapse:collapse;
  margin:0px;
  padding:7px;}
  button{
	  background-color: #006;
	  border-radius: 12px;
    border: none;
    color: white;
    padding: 6px 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
  }
  button:hover{background-color:#909;}
  </style>
</head>
<body>
<?php
include('connection.php');
$sql = "SELECT * FROM staff ORDER BY Date";
$que1= mysqli_query($con,$sql);
if($que1){
	$num=mysqli_num_rows($que1);
	if(!$num){
        echo"<script> alert(\"Sorry! No Staff Found!\")</script>";
		exit;
		}
		else{
			?>
            <div id="div1">
            <center>
		
			<table border="0" width="56%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0"><caption><font color="black"><h3>Our Staff</h3></font></caption>
			</table>
            <?php
            $i=1;
			while($tab=mysqli_fetch_array($que1)){
        $FirstName=$tab['FirstName'];
        $LastName=$tab['LastName'];
        $name = $FirstName . " " .$LastName;
        $Email=$tab['Email'];
				?>
        <?php 
        if($i%2==1)
          {
          $i=$i+1; 
          ?>
				<table border="0" width="56%" bordercolor="#000000" bordercolordark="#000000" bgcolor="#FFCC99" cellpadding="0"><tr><td width="28%">
				<?php echo'<img  src="data:image/jpeg;base64,'.base64_encode($tab['Image'] ).'" height="400" width="100%" />  ';?><br/>
				<?php echo"<strong>".$name."&nbsp;&nbsp;</strong>"."<strong>".$Email."</strong>"; ?></td>
      <?php 
        }
        else{
          $i=$i+1;
          ?>
          <td width="28%">
       <?php echo'<img  src="data:image/jpeg;base64,'.base64_encode($tab['Image'] ).'" height="400" width="100%" />  ';?> <br/>
       <?php echo"<strong>".$name."&nbsp;&nbsp;</strong>"."<strong>".$Email."</strong>"; ?></td></tr>
				<?php 
        }
      }
      echo"</table>";
		}
}
				?>
				
				</cente>
<br /><br />
          
                         </center>
                         </div>
                         <center>
                           <!-- <button onclick="printContent('div1')">Print</button> -->
                    </center> 

</body>
</html>