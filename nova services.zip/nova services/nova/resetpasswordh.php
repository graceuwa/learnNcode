<?php
if(isset($_POST["rest-password-submit"])){
	$selector = $_POST["selector"];
	$validator = $_POST["validator"];
	$password = $_POST["pwd"];
	$passwordRepeat = $_POST["pwdRepeat"];
	if(empty($password)||empty($passwordRepeat)){
		header("Location: createnewpassword.php?newpwd=empty");
	}
	else if($password !== $passwordRepeat){
		header("Location: createnewpassword.php?newpwd=pwdnotsame");
		exit();
	}
	$currentDate = date("U");
	include("connection.php");
	$sql = "SELECT * FROM pwdreset WHERE pwdResetSelector = '$selector' AND  pwdResetExpires >= '$currentDate'";
	$que1 =mysqli_query($con,$sql);
	if(!mysqli_query($con,$sql)){
		echo"There was an error";
		exit();
	}
	else{
		if(!row=mysqli_fetc_array($que1)){
			echo"You need to resubmit your reset request";
			exit();
		}
		else{
			$tokenBin = hex2bin($validator);
			$tokenCheck = password_verify($token, $row["pwdResetToken"]);
			if($tokenCheck === false){
				echo"you need to re-submit your reset request";
				exit();
			}
			else if($tokenCheck === true){
				$tokenEmail = $row["pwdResetEmail"];
				$sql1 ="SELECT * FROM registration WHERE email = '$tokenEmail'";
				$que3 =mysqli_query($con,$sql1);
				$row1 =mysqli_fetch_array($que3);
				$emailUpdate = $row1['email'];
				$sql2 ="UPDATE registration SET password = '$password' WHERE email = '$emailUpdate'";
				$que4 =mysqli_query($con,$sql2);
				if($que4){
					$sql3 ="DELETE FROM pwdreset WHERE pwdResetEmail = '$emailUpdate'";
				$que5 =mysqli_query($con,$sql2);
				if($que5){
					echo"<script>alert('Your password have been reset successfully')</script>";
				}
				}

			}
		}
	}
}
?>