<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Training</title>
</head>
<body>
	<?php
	$trainingId = $_POST['trainingId'];
	$trainingTitle = $_POST['title'];
	$trainingDescription = $_POST['description'];
	$price = $_POST['price'];
	$status = $_POST['status'];
	$startDate = $_POST['startDate'];
	$endDate = $_POST['endDate'];
	$userId = $_POST['userId'];
	include('connection.php');
	$sql1 = "UPDATE training SET Title = '$trainingTitle', Description = '$trainingDescription',  Status = '$status', Price = '$price', StartDate = '$startDate', EndDate = '$endDate', UserId = '$userId' WHERE TrainingId = '$trainingId'";
	$que1 = mysqli_query($con,$sql1);
	if($que1){
    	echo"<script>alert('Training Successfullly Updated')</script>";
	}else{
    	echo"Error Updating Training".mysqli_error($con);
	}
	mysqli_close($con);
	?>
</body>
</body>
</html>