<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Find User</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
include('connection.php');
	$sql1 = "SELECT UserName FROM users ORDER BY Date";
	$que1 = mysqli_query($con,$sql1);
?>
<div class="container">

	<form class="myform" action="finduser.php" method="post">
		<h2>Find User to update. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Select Username (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="userName" required="">
				<?php
				while($row = mysqli_fetch_array($que1)){
					$usname = $row['UserName'];
					?>
					<option><?php echo $usname; ?></option>
					<?php
				}
				?>
			</select>
			
		</div>
		<input class="button" type="submit" name="find" value="Find">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>