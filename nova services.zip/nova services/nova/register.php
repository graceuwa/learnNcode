<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<link rel="stylesheet" type="text/css" href="style4.css">
    <link rel="stylesheet" type="text/css" href="style2.css">
	 <!-- <link rel="stylesheet" href="build/css/intlTelInput.css">
  <link rel="stylesheet" href="build/css/demo.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/css/intlTelInput.min.css" /> -->
</head>
<body>
<?php
include('connection.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
    $firstName = prepare_input($_POST['firstName']);
    $lastName = prepare_input($_POST['lastName']);
    $gender = prepare_input($_POST['gender']);
    $dob = prepare_input($_POST['dob']);
    $jobTite = prepare_input($_POST['jobTite']);
    $educationLevel = prepare_input($_POST['educationLevel']);
    $phoneNumber = prepare_input($_POST['phoneNumber']);
    $email = prepare_input($_POST['email']);
    $county = prepare_input($_POST['county']);
    $district = prepare_input($_POST['district']);
    $password = prepare_input($_POST['password']);
    $password = sha1($password);

    $sql = "insert into trainee(`firstName`,`LastName`,`gender`,`dateOfBirth`,`jobTitle`,`educationLevel`,`mobilePhone`,`email`,`country`,`district`,`regDate`,`UserId`) values('$firstName','$lastName','$gender','$dob','$jobTite','$educationLevel','$phoneNumber','$email','$county','$district', now(),'1')";

    $sql1 = "insert into users(`FirstName`,`LastName`,`UserName`,`Password`,`Priority`,`Status`) values('$firstName','$lastName','$email','$password','Trainee','Active')"; 
    if(mysqli_query($con,$sql) && mysqli_query($con,$sql1)){
        echo"<script>alert('Record Added Successfullly')</script>";
        //echo "<meta http-equiv='refresh' content='0;url=trainee.php'>";
    }else{
        echo"Error Adding Record".mysqli_error($con);
    }
	mysqli_close($con);
}
?>
<div class="container">

	<form class="myform" action="" method="post">
		<h2>Fill in the Registration form. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
		<div class="forminput">
            <label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="text" name="firstName" required="" placeholder="Enter the first name">
        </div>
        <div class="forminput">
            <label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="text" name="lastName" required="" placeholder="Enter the last name">
        </div>
        <div class="forminput">
            <label>Gender (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="radio" name="gender" required="" value="Male" width="20px"><span style="color:#fff;">Male</span>
            <input type="radio" name="gender" required="" value="Female" width="20px"><span style="color:#fff;">Female</span>
        </div>
        <div class="forminput">
            <label>DoB (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="date" name="dob" required="">
        </div>
        <div class="forminput">
            <label>Job title </label>
            <input type="text" name="jobTite" placeholder="Enter the job title">
        </div>
        <div class="forminput">
            <label>Education Level (<span style="color: red; font-size: 20px;">*</span>)</label>
            <select name="educationLevel" required="">
                <option value="">--select level--</option>
                <option value="O Level">O Level</option>
                <option value="A Level">A Level</option>
                <option value="Diploma">Diploma(A1)</option>
                <option value="Bachelor">Bachelor's Degree(A0)</option>
                <option value="Post Graduate Diploma">Post Graduate Diploma</option>
                <option value="Master">Master's Degree</option>
                <option value="PhD">PhD</option>
            </select>
        </div>
        <div class="forminput">
            <label>Phone number (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="text" maxlength="10" name="phoneNumber" required="" placeholder="Enter the phone number 078####### / 079####### / 072####### /073#######" onkeypress="return (event.charCode <= 31 || (event.charCode >= 48 && event.charCode <= 57))" pattern="[0][7][8/9/2/3][0-9]{7}">
        </div>
        <div class="forminput">
            <label>Email (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="email" name="email" required="" placeholder="Enter the email">
        </div>
        <div class="forminput">
            <label>Country (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="text" name="county" required="" placeholder="Enter the country">
        </div>
        <div class="forminput">
            <label>District (<span style="color: red; font-size: 20px;">*</span>)</label>
            <input type="text" name="district" required="" placeholder="Enter the district">
        </div>
		<div class="forminput">
			<label>Password <span style="color: red; font-size: 20px;">*</span></label>
			<input type="password" id="password1" name="password" required="" placeholder="choose your password">
		</div>
		<div class="forminput">
			<label>Confirm Password <span style="color: red; font-size: 20px;">*</span></label>
			<input type="password" id="password2" name="confirmpassword" required="" placeholder="Confirm your password" onfocusout="password_match()">
		</div>
		<!-- The result will show in this div -->
     <div id="show-result">
  	</div>
    <!-- <div class="forminput">
            <label>Protection of privacy <span style="color: red; font-size: 20px;">*</span>&nbsp;&nbsp;<a class="button" href="images/CTC_GDPR_TEMPLATE.pdf" target="_blank">Read</a></label><br>
            <input style="width: 10px;" type="checkbox" name="privacy" required=""><span style="width:30%; color: #fff;"> I declare that I have read CTC's Privacy Protection Charter and accept that CTC processes my personal data in accordance with it.</span>
        </div>
 -->
		<input style="width: 100px;" class="button" type="submit" name="save" value="Register">
		<input style="width: 100px;" class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
<!-- <script src="jquery-3.3.1.js"></script> -->
   <script>
   function password_match(){
    var password1 = document.getElementById('password1').value ; 
    var password2 = document.getElementById('password2').value ; 
    if(password1 != password2){
    	document.getElementById('show-result').innerText ="Password not matching";
    	document.getElementById('password2').focus;
    	document.getElementById('show-result').style.borderColor="red";
    	document.getElementById('show-result').style.color="red";
    	return false;
    } 
    else{
        document.getElementById('show-result').innerText ="";
    	return true;
    }
    }
   </script>
  
<!-- <script src="build/js/intlTelInput.js"></script> -->
<!--   <script>
    var input = document.querySelector("#phone");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
      // hiddenInput: "full_number",
      // initialCountry: "auto",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      // separateDialCode: true,
      utilsScript: "build/js/utils.js",
    });
  </script>
  <script>
    var input = document.querySelector("#phone1");
    window.intlTelInput(input, {
      // allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: document.body,
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
      // geoIpLookup: function(callback) {
      //   $.get("http://ipinfo.io", function() {}, "jsonp").always(function(resp) {
      //     var countryCode = (resp && resp.country) ? resp.country : "";
      //     callback(countryCode);
      //   });
      // },
      // hiddenInput: "full_number",
      // initialCountry: "auto",
      // localizedCountries: { 'de': 'Deutschland' },
      // nationalMode: false,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
      // separateDialCode: true,
      utilsScript: "build/js/utils.js",
    });
  </script> -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/intlTelInput.min.js"></script>

<script>
  var input = document.querySelector("#phone");
  window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(success) {
      // Get your api-key at https://ipdata.co/
      fetch("https://api.ipdata.co/?api-key=test")
        .then(function(response) {
          if (!response.ok) return success("");
          return response.json();
        })
        .then(function(ipdata) {
          success(ipdata.country_code);
        });
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.min.js",
  });
</script>
<script>
  var input = document.querySelector("#phone1");
  window.intlTelInput(input, {
    initialCountry: "auto",
    geoIpLookup: function(success) {
      // Get your api-key at https://ipdata.co/
      fetch("https://api.ipdata.co/?api-key=test")
        .then(function(response) {
          if (!response.ok) return success("");
          return response.json();
        })
        .then(function(ipdata) {
          success(ipdata.country_code);
        });
    },
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.3/js/utils.min.js",
  });
  // function countryname(){
  //       var ctry = document.querySelector('.iti__selected-flag').title;
  //       console.log(ctry)
        
  //       // var myctr = document.getElementById('mycountry')
  //       // myctr.value = mytitle

  //      }
  // countryname()
</script>
<!-- <script type="text/javascript">
       function countryname(){
        var ctry = document.querySelector('.iti__selected-flag').title;
        console.log(ctry)
        
        // var myctr = document.getElementById('mycountry')
        // myctr.value = mytitle

       }
   </script>
<script type="text/javascript">
    countryname()
</script> -->
</body>
</html>