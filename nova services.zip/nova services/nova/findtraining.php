<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Update Training</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
$trainingId = $_POST['trainingId'];
include('connection.php');
	$sql1 = "SELECT * FROM training WHERE TrainingId = '$trainingId'";
	$que1 = mysqli_query($con,$sql1);
	$row = mysqli_fetch_array($que1);
	$trainingCode = $row['TrainingCode'];
	$title = $row['Title'];
	$description = $row['Description'];
	$status = $row['Status'];
	$price = $row['Price'];
	$startDate = $row['StartDate'];
	$endDate = $row['EndDate'];
	$date = $row['RegDate'];
	$userId = $row['UserId'];
?>
<div class="container">

	<form class="myform" action="hfindtraining.php" method="post">
		<h2>Change required Fields. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Training Code (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" class="read" name="trainingCode" readonly="" value="<?php echo $trainingCode; ?>">
		</div>
		<div class="forminput">
			<label>Title (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" class="read" name="title" value="<?php echo $title; ?>">
		</div>
		
		<div class="forminput">
			<label>Description (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="description" class="read" value="<?php echo $description; ?>" >
		</div>
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="status" required="">
				<option><?php echo $status; ?></option>
				<?php 
				if($status == "Active")
				{
					?>
					<option value="Inactive">Inactive</option>
					<?php
				}
				else{
					?>
					<option value="Active">Active</option>
					<?php
				}
				?>
				
			</select>
		</div>
		<div class="forminput">
			<label>Price (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="number" name="price" required="" value="<?php echo $price; ?>">
		</div>
		<div class="forminput">
			<label>Start Date </label>
			<input type="date" name="startDate" value="<?php echo $startDate; ?>">
		</div>
		<div class="forminput">
			<label>End Date </label>
			<input type="date" name="endDate" value="<?php echo $endDate; ?>">
		</div>
		<input type="hidden" class="read" name="trainingId" readonly="" value="<?php echo $trainingId; ?>">
		<input type="hidden" class="read" name="userId" readonly="" value="<?php echo $userId; ?>">
		<input class="button" type="submit" name="update" value="Update">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>