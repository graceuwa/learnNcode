<!DOCTYPE html>
<html>
<head>
	<title>CTF</title>
		<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
	<div class="container">
		<h2>CTF</h2>
		<p>A multitude of laws and regulations have been enacted to reign in the financing of terrorist activity, and are collectively known as counter-terrorist financing policy (this may be abbreviated as CTF). Under these policies, most financial institutions are obliged to fulfil many strict requirements regarding monitoring customers’ transactions and behaviours.</p>
		<a class="button" href="readtraining1.html">Go Back</a>
	</div>
</body>
</html>