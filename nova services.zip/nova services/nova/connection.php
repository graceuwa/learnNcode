<?php
$con = mysqli_connect('localhost','root','','novaservices') or die('Unable To connect');
function prepare_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data, ENT_QUOTES);
  //$data = htmlentities($data, ENT_QUOTES);
  return $data;
}
?>