<!DOCTYPE html>
<html>
<head>
	<title>Business Analysis</title>
	<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
	<div class="container">
		<h2>Business analysis</h2>
		<p>
			This program is designed to hone your expertise in the latest Business analytics tools and techniques, including planning and monitoring, data analysis and statistics and visualizations. This course will train you in a practical manner with real-world case studies, ensuring that you’re market-ready.
		</p>
		<a class="button" href="readtraining1.html">Go Back</a>
	</div>
</body>
</htm