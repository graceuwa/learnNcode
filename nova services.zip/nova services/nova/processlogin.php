<?php
if(isset($_POST['login']))
{
session_start();
$_SESSION["user"] = "";
$_SESSION["priority"] = "";
$userName = "";
$password="";
include('connection.php');

$userName = prepare_input($_POST['userName']);
$password = prepare_input($_POST['password']);
$password = sha1($password);
// echo"Username = " . $userName . " and password = " . $password;
// exit;

$sql = "select * from users where UserName='$userName' and Password='$password'";
$que1= mysqli_query($con,$sql);
if($que1){
	$num=mysqli_num_rows($que1);
	if($num){
		$tab = mysqli_fetch_array($que1);
		$fanme = $tab['FirstName'];
		$lanme = $tab['LastName'];
		$priority = $tab['Priority'];
		$statu = $tab['Status'];
		// $id = $tab['UserId'];
		$_SESSION["userId"] = $tab['UserId'];
		$_SESSION["priority"] = $tab['Priority'];

		if($priority == "Trainee"){
			echo"<script>alert('Sorry. You cannot login as Admin')</script>";
			include('index.php');
			exit;
		}else if($statu == "Inactive"){
			echo"<script>alert('Sorry. Your account is Inactive. Please Consult System Administrator')</script>";
			include('index.php');
			exit;
		}else{
			echo"<script>alert('Welcome $fanme $lanme ')</script>";
			include('indexadmin.php');
			exit;
		}
        
	}
	else{
        echo"<script>alert('Incorrect Username/Password. Try again!')</script>";
        include("login.php");
	}
}
else{
	echo"Error ".mysqli_error($que1);
}
}
?>
