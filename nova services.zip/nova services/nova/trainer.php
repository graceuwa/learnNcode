<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $userId = $_SESSION["userId"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Trainer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style type="text/css">
	#body{
  background: url('images/training1.jpg') no-repeat;
  background-size: cover;
	background-position: center;
	margin: 0;
	padding: 0;
}
		#myInput{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}

table{ table-layout:auto;}
@page    {
  size: auto;  
  margin: 20px;  
 }
table,tr,th,td{border-spacing:0px;
  border-collapse:collapse;
  margin:0px;
  padding:7px;
  word-wrap: break-word;}
  table { page-break-after:auto }
  tr    { page-break-inside:avoid;page-break-after:auto }
  td    { page-break-inside:auto; page-break-after:auto }
caption{
    font-weight: bold;
}

	</style>
</head>
<body style="margin: 20px;" id="body">
	<center>
	<?php
include('connection.php');
if(isset($_GET['action']) && $_GET['action'] == "add"){
	include('addtrainer.php');
}else if(isset($_POST['saveTrainer'])){
	$firstName = prepare_input($_POST['firstName']);
	$lastName = prepare_input($_POST['lastName']);
	$nationality = prepare_input($_POST['nationality']);
	$address = prepare_input($_POST['address']);
	$phoneNumber = prepare_input($_POST['phoneNumber']);
	$email = prepare_input($_POST['email']);
	$qualification = prepare_input($_POST['qualification']);
	$domain = prepare_input($_POST['domain']);
	$sql = "insert into trainer(`FirstName`,`LastName`,`Nationality`,`Address`,`Telephone`,`Email`,`Qualification`,`Domain`,`RegDate`,`UserId`) values('$firstName','$lastName','$nationality','$address','$phoneNumber','$email','$qualification','$domain', now(),'$userId')";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainer Added Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainer.php'>";
	}else{
    	echo"Error Adding Trainer".mysqli_error($con);
	}
	
}else if(isset($_GET['action']) && $_GET['action'] == "edit"){
	$trainerId = $_GET['edit'];
	$sql = "SELECT * FROM trainer WHERE TrainerId = " . $trainerId;
	$que1= mysqli_query($con,$sql);
	$row = mysqli_fetch_array($que1);
	extract($row);
	include('edittrainer.php');

}else if(isset($_POST['updateTrainer'])){
	$trainerId = prepare_input($_POST['trainerId']);
	$firstName = prepare_input($_POST['firstName']);
	$lastName = prepare_input($_POST['lastName']);
	$nationality = prepare_input($_POST['nationality']);
	$address = prepare_input($_POST['address']);
	$phoneNumber = prepare_input($_POST['phoneNumber']);
	$email = prepare_input($_POST['email']);
	$qualification = prepare_input($_POST['qualification']);
	$domain = prepare_input($_POST['domain']);

	$sql = "update trainer set FirstName = '$firstName', LastName = '$lastName', Nationality = '$nationality', Address = '$address', Telephone = '$phoneNumber', Email = '$email', Qualification = '$qualification', Domain = '$domain', RegDate = NOW(), UserId = '$userId' where TrainerId = '$trainerId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainer Updated Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainer.php'>";
	}else{
    	echo"Error Updating Trainer".mysqli_error($con);
	}

}else if(isset($_GET['action']) && $_GET['action'] == "delete"){
	$trainerId = $_GET['delete'];
	$sql = "delete from trainer where TrainerId = '$trainerId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainer Deleted Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainer.php'>";
	}else{
    	echo"Error Deleting Trainer".mysqli_error($con);
	}
} else{
	$sql = "SELECT * FROM trainer ORDER BY TrainerId";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			
				<input type="text" id="myInput" placeholder="Search for trainers...">
				<a href="trainer.php?action=add" target="fr" class="btn btn-primary">Add Trainer</a>
			<div id="printdiv">
				<div><h4 class="text text-info text-center">List of Trainers</h4></div>
			<table border="1" class="table table-bordered" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0">
		<thead>
			<tr><th>#</th><th>First Name</th><th>Last Name</th><th>Nationality</th><th>Telephone</th><th width="15%">Email</th><th>Qualification</th><th>Domain</th><th class="no-print">Perform</th></tr>
		</thead>
		<tbody id="myTable">
			<?php
			$i=1;
			while($row = mysqli_fetch_array($que1)){
				$trainerId = $row['TrainerId'];
				$firstName = $row['FirstName'];
				$lastName = $row['LastName'];
				$trainerName = $firstName . " " . $lastName;
				$nationality = $row['Nationality'];
				$address = $row['Address'];
				$telephone = $row['Telephone'];
				$email = $row['Email'];
				$qualification = $row['Qualification'];
				$domain = $row['Domain'];
				// $user = $row['User'];
				?>
				<!-- <table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0" id="myTable"> -->
			 
				<tr><td>
				<?php echo $i;?></td><td>
				<?php echo $firstName;?></td><td>
				<?php echo $lastName;?></td><td>
				<?php echo $nationality;?></td><td>
				<?php echo $telephone;?></td><td width="15%">
				<?php echo $email;?></td><td>
				<?php echo $qualification;?></td><td>
				<?php echo $domain;?></td><td class="no-print">
					<a href="trainer.php?action=edit&edit=<?php echo $trainerId;?>" title="Edit Trainer <?php echo $trainerName;?>">
						<i class="fa fa-pencil-square-o text-dark"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="trainer.php?action=delete&delete=<?php echo $trainerId;?>" title="Delete Trainer <?php echo $trainerName;?>" onclick="return confirm('Are you sure you want to delete trainer <?php echo $trainerName;?>?');"><i class="fa fa-minus-circle text-danger"></i></a></td>

				</tr>
			
				<?php
				$i += 1;
			}
			?>
			</tbody></table>
			</div>
			<center>
			<button class="printbtn" onclick="printContent('printdiv')">Print</button>
		</center>
			<?php
			// exit;
		}
		else{
        	echo'<a href="trainer.php?action=add" target="fr" class="btn btn-primary">Add Trainee</a>';
        	echo'<p class="text text-danger">No Trainers Found</p>';
		}
}
else{
	echo"Cannot Display".mysqli_error($con);
}
}
?>

</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
function printContent(el){
		// let nop = document.querySelectorAll('.no-print').style.display = 'none';
		let nop = document.querySelectorAll('.no-print');
		let body = document.getElementById('body');

		for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'none';
		}
		//body.style.backgroundSize= "auto";
		body.style.backgroundImage = "url('white.jpg')";
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();

    for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'block';
		}
		document.body.innerHTML = restorepage;
		window.location.reload(true);
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>

  <script>

$("#myInput").on("keyup",function(){
        var value = $(this).val().toLowerCase();
        //location.reload(true);

        $("#myTable tr").filter(function(){
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });

      });
</script>
</body>
</html>
