<!DOCTYPE html>
<html>
<head>
	<title>View Traings</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
		#myInput{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}
	</style>
</head>
<body style="margin: 20px;">
	<center>
	<?php
include('connection.php');
$sql = "SELECT * FROM training ORDER BY Status, RegDate";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			<div id="printdiv">
				<input type="text" id="myInput" placeholder="Search for trainings..">
			<table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0"><caption><font color="black"><h3>List of Training</h3></font></caption>
		<thead>
			<tr><th width="7%">Training code</th><th width="12%">Title</th><th width="21%">Description</th><th width="10%">Status</th><th width="10%">Price(Frw)</th><th width="15%">Start Date</th><th width="15%">End Date</th><th width="10%">Reg. Date</th></tr>
		</thead>
		<tbody id="myTable">
			<?php
			while($row = mysqli_fetch_array($que1)){
				$trainingId = $row['TrainingId'];
				$trainingCode = $row['TrainingCode'];
				$title = $row['Title'];
				$description = $row['Description'];
				$status = $row['Status'];
				if($status == "Active"){
					$status = "Ongoing";
				}
				$price = $row['Price'];
				$startDate = $row['StartDate'];
				$endDate = $row['EndDate'];
				$date = $row['RegDate'];
				// $user = $row['User'];
				?>
				<!-- <table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0" id="myTable"> -->
			 
				<tr><td width="7%">
				<?php echo $trainingCode;?></td><td width="12%">
				<?php echo $title;?></td><td width="21%">
				<?php echo $description;?></td><td width="10%">
				<?php echo $status;?></td><td width="10%">
				<?php echo $price;?></td><td width="15%">
				<?php echo $startDate;?></td><td width="15%">
				<?php echo $startDate;?></td><td width="10%">
				<?php echo $date;?></td>
				</tr>
			
				<?php
			}
			?>
			</tbody></table>
			</div>
			<center>
			<button class="printbtn" onclick="printContent('printdiv')">Print</button>
		</center>
			<?php
			// exit;
		}
		else{
        	echo"<script>alert(\"Sorry! Trainings not registered!\")</script>";
		}
}
else{
	echo"Cannot Display".mysqli_error($con);
}
?>

</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>

  <script>
// function myFunction() {
//   // Declare variables
//   // var input, filter, table, tr, td, i, txtValue;
//   // input = document.getElementById("myInput");
//   // filter = input.value.toUpperCase();
//   // table = document.getElementById("myTable");
//   // tr = table.getElementsByTagName("tr");

//   // // Loop through all table rows, and hide those who don't match the search query
//   // for (i = 0; i < tr.length; i++) {
//   //   td = tr[i].getElementsByTagName("td")[0];
//   //   if (td) {
//   //     txtValue = td.textContent || td.innerText;
//   //     if (txtValue.toUpperCase().indexOf(filter) > -1) {
//   //       tr[i].style.display = "";
//   //     } else {
//   //       tr[i].style.display = "none";
//   //     }
//   //   }
//   // }


// }

$("#myInput").on("keyup",function(){
        var value = $(this).val().toLowerCase();
        //location.reload(true);

        $("#myTable tr").filter(function(){
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });

      });
</script>
</body>
</html>
