<?php
session_start();
$courses = $_SESSION['courses'];
$totalamount = $_SESSION['totalamount'];
$totalamount1 = substr($totalamount, 1);
$totalamount2 = $totalamount1 . "00";
require_once('vendor/autoload.php');
require_once('config/db.php');
require_once('lib/pdo_db.php');
require_once('models/Customer.php');
require_once('models/Transaction.php');
//\Stripe\Stripe::setApiKey('sk_test_51HdAxuLTgOvcUMDrvy847g4nRa8sEdGYZwTL2WoH4qFoSlmQScGn9lRUzIQOXhnWH9hBGfBOQvG16b6mbeW0Ryqt00HXqdzxkn');
\Stripe\Stripe::setApiKey('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');
// $customer = $stripe->customers->create([
//     'description' => 'example customer',
//     'email' => 'email@example.com',
//     'payment_method' => 'pm_card_visa',
// ]);
// echo $customer;
// Sanitize POST Array
 $POST = filter_var_array($_POST, FILTER_SANITIZE_STRING);

// print_r($POST);
// exit;

 // $first_name = $POST['first_name'];
 // $last_name = $POST['last_name'];
 // $email = $POST['email'];
 $first_name = $_SESSION["fname"];
 $last_name = $_SESSION["lname"];
 $email = $_SESSION["usernamepay"];
 $token = $POST['stripeToken'];

// Create Customer In Stripe
$customer = \Stripe\Customer::create(array(
  "email" => $email,
  "source" => $token
));

// Charge Customer
$charge = \Stripe\Charge::create(array(
  // "amount" => 5000,
  "amount" => $totalamount2,
  "currency" => "usd",
  // "description" => "Intro To Business Management",
  "description" => $courses,
  "customer" => $customer->id
));
// Customer Data
$customerData = [
  'id' => $charge->customer,
  'first_name' => $first_name,
  'last_name' => $last_name,
  'email' => $email
];

// Instantiate Customer
$customer = new Customer();

// Add Customer To DB
$customer->addCustomer($customerData);

// Transaction Data
$transactionData = [
  'id' => $charge->id,
  'customer_id' => $charge->customer,
  'product' => $charge->description,
  'amount' => $charge->amount,
  'currency' => $charge->currency,
  'status' => $charge->status,
];

// Instantiate Transaction
$transaction = new Transaction();

// Add Transaction To DB
$transaction->addTransaction($transactionData);

// header('Location: success.php?tid='.$charge->id.'&product='.$charge->description);

$to = $email;
$message = "Thank you for purchasing the course(s) " . $charge->description. " \r\nYour transaction id is " .$charge->id. ".\r\n your payment of ". $totalamount . " was successful";
  $body .= $message."\r\n";
  // $ctcconfidential = "This e-mail is confidential and for the exclusive use of the recipient(s). If you are not the intended recipient, you must not disclose, copy, distribute or take any action based on this e-mail. If you have received this email in error, it would be helpful if you could notify Progressive , company at info@cleartrustconsulting.com as soon as possible. Company CTC- SRL |130 rue d'Arlon, 6780 Messancy -Belgium";
  $ctcconfidential = "This e-mail is confidential and for the exclusive use of the recipient(s). If you are not the intended recipient, you must not disclose, copy, distribute or take any action based on this e-mail.
   If you have received this email in error, it would be helpful if you could notify Progressive , company at info@cleartrust.eu as soon as possible. Company CTC- SRL |130 rue d'Arlon, 6780 Messancy -Belgium";
   $body .= "\r\n";
  $body .= "\r\n";
  $body .= $ctcconfidential."\r\n";
  $messageSubject = "purchase sucess";
  $from = "info@cleartrustconsulting.com";
  $headers = "From: ClearTrust Consulting <info@cleartrustconsulting.com>\r\n";
  $headers .= "Reply-To: info@cleartrustconsulting.com\r\n";
  $headers .= "content-type: text/html\r\n";
  mail($to, $messageSubject, $body, $headers);
  // echo"<script> ";
  //       echo"alert(\"Hello $first_name  $last_name . Your purchase is sucessfully processed. Please check in your email \")";
  //       echo"</script>";
header('Location: success.php?tid='.$charge->id.'&product='.$charge->description.' Total Amount paid='.$totalamount);
?>