<?php
  // DB Params
  define("DB_HOST", "localhost");
  define("DB_USER", "cleartrustconsulting_comcreartrustconsulting");
  define("DB_PASS", "ctc2020");
  define("DB_NAME", "cleartrustconsulting_comcreartrustconsulting");