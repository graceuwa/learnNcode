// <p class="cart-item-image">${imageSrc}</p>

<span class="cart-item-title">${title}</span>
 <input type="text"  name="decr${iu}" value="${imageSrc}">
 <input class="cart-quantity-input" type="number" value="1">