<!DOCTYPE html>
<html>
<head>
	<title>Add Staff</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
	$firstName=$_POST['firstName'];
	$lastName=$_POST['lastName'];
	$phone=$_POST['phone'];
	$email=$_POST['email'];
	$nationality=$_POST['nationality'];
	$address=$_POST['address'];
	$nationalId=$_POST['nationalId'];
	$image = $_FILES['image']['tmp_name'];
	$img = addslashes(file_get_contents($image));
	include('connection.php');
	$sql = "insert into staff(`FirstName`,`LastName`,`Nationality`,`NationalId`,`Address`,`Telephone`,`Email`,`Image`,`Date`) values('$firstName','$lastName','$nationality','$nationalId','$address','$phone','$email','$img', now())";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Staff Successfullly Added')</script>";
	}else{
    	echo"Error Adding staff".mysqli_error($con);
	}
	mysqli_close($con);
}
?>
<div class="container">

	<form class="myform" action="" method="post" enctype="multipart/form-data">
		<h2>Fill in Staff's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>First Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="firstName" required="" placeholder="Enter the first name">
		</div>
		<div class="forminput">
			<label>Last Name (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="lastName" required="" placeholder="Enter the last name">
		</div>
		<div class="forminput">
			<label>Nationality (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="nationality" required="" placeholder="Nationality">
		</div>
		<div class="forminput">
			<label>Id/Passport (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="nationalId" required="" placeholder="Nationality">
		</div>
		<div class="forminput">
			<label>Address (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="address" required="" placeholder="Address">
		</div>
		<div class="forminput">
			<label>Telephone (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="phone" required="" placeholder="Phone number">
		</div>
		<div class="forminput">
			<label>Email Id (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="email" name="email" required="" placeholder="Email Id">
		</div>
		<div class="forminput">
			<label>Upload Photo (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="file" name="image" required="" />
		</div>
		<input class="button" type="submit" name="save" value="Save">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>