<!DOCTYPE html>
<html>
<head>
	<title>AML</title>
	<link rel="stylesheet" type="text/css" href="styletraining.css">
</head>
<body>
<div class="container">
	<h2>AML: Anti -Money Laundering </h2>
	<p>At the end of this training course, you will have a good general understanding of the mechanisms involved in money laundering and terrorism financing. You will get a good knowledge of the principles and techniques to be applied to counter them effectively.
	</p>
	<p>
		It’s a crime that allows the background origin to be concealed. The objective of anti-money laundering (AML) is to deter criminals from feeding their illicit funds into the financial system. Criminals use money laundering to hide the true source of their money that has been derived from crimes.
	</p>
	<a class="button" href="readtraining1.html">Go Back</a>
</div>

</body>
</html>
