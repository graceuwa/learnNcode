<!DOCTYPE html>
<html>
<head>
	<title>Forgot password</title>
		<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<div class="container">
	<h3>Reset your password</h3>
	<p>An e-mail will be sent to you with instructions on how to reset your password</p>

	<form class="myform" action="resetrequest.php" method="post">
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Email (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="email" name="email" required="" placeholder="Enter your e-mail address ...">
		</div>
		<input class="button" type="submit" name="resetpassowrd" value="Submit Request">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
	<?php
	if(isset($_GET["reset"])){
		if($_GET["reset"]==="success"){
			echo'<p class="message">Check your e-mail!</p>';
		}
	}
	?>
</div>
</body>
</html>