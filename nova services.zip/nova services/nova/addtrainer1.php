<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $username = $_SESSION["user"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Training</title>
	<link rel="stylesheet" type="text/css" href="style2.css">
</head>
<body>
<?php
if($_SERVER['REQUEST_METHOD']=='POST'){
	$trainingId=$_POST['trainingId'];
	$title=$_POST['title'];
	$field=$_POST['field'];
	$description=$_POST['description'];
	$status=$_POST['status'];
	$price=$_POST['price'];
	$startDate=$_POST['startDate'];
	include('connection.php');
	$sql = "insert into training(`TrainingId`,`Title`,`Field`,`Description`,`Status`,`Price`,`StartDate`,`Date`,`User`) values('$trainingId','$title','$field','$description','$status','$price','$startDate',now(),'$username')";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Training Successfullly Added')</script>";
	}else{
    	echo"Error Adding Training".mysqli_error($con);
	}
	mysqli_close($con);
}
?>
<div class="container">

	<form class="myform" action="" method="post">
		<h2>Fill in Training's Details. </h2>
		<p style="color: red;">(*) Mandatory fields</p>
		<div class="forminput">
			<label>Training Id (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="trainingId" required="" placeholder="Enter the training id">
		</div>
		<div class="forminput">
			<label>Title (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="title" required="" placeholder="Enter the training title">
		</div>
		<div class="forminput">
			<label>Field (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="field" required="">
				<option>Accounting</option>
				<option>Finance</option>
			</select>
		</div>
		<div class="forminput">
			<label>Description (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="text" name="description" required="" placeholder="Enter training Description">
		</div>
		<div class="forminput">
			<label>Status (<span style="color: red; font-size: 20px;">*</span>)</label>
			<select name="status" required="">
				<option>Active</option>
				<option>Inactive</option>
			</select>
		</div>
		<div class="forminput">
			<label>Price (<span style="color: red; font-size: 20px;">*</span>)</label>
			<input type="number" name="price" required="" placeholder="price in $">
		</div>
		<div class="forminput">
			<label>Start Date</label>
			<input type="date" name="startDate" placeholder="Starting date">
		</div>
		<input class="button" type="submit" name="save" value="Save">
		<input class="button" type="reset" name="reset" value="Clear Form">
	</form>
</div>
</body>
</html>