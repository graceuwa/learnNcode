<?php
if (session_status() == PHP_SESSION_NONE) {
      session_start();
   }
   $userId = $_SESSION["userId"];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Trainer</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="style2.css">
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
<link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
	<style type="text/css">
	#body{
  background: url('images/training1.jpg') no-repeat;
  background-size: cover;
	background-position: center center;
	margin: 0;
	padding: 0;
}
		#myInput{
	
	width:45%;
	border-radius: 20px;
	outline:none;
	padding:3px;
	transition: 0.25s;
}

table{ table-layout:auto;}
@page    {
  size: auto;  
  margin: 20px;  
 }
table,tr,th,td{border-spacing:0px;
  border-collapse:collapse;
  margin:0px;
  padding:7px;
  word-wrap: break-word;}
  table { page-break-after:auto }
  tr    { page-break-inside:avoid;page-break-after:auto }
  td    { page-break-inside:auto; page-break-after:auto }
caption{
    font-weight: bold;
}

	</style>
</head>
<body style="margin: 20px;" id="body">
	<center>
	<?php
include('connection.php');
if(isset($_GET['action']) && $_GET['action'] == "add"){
	include('addtrainee.php');
}else if(isset($_POST['saveTrainee'])){
	$firstName = prepare_input($_POST['firstName']);
	$lastName = prepare_input($_POST['lastName']);
	$gender = prepare_input($_POST['gender']);
	$dob = prepare_input($_POST['dob']);
	$jobTite = prepare_input($_POST['jobTite']);
	$educationLevel = prepare_input($_POST['educationLevel']);
	$phoneNumber = prepare_input($_POST['phoneNumber']);
	$email = prepare_input($_POST['email']);
	$county = prepare_input($_POST['county']);
	$district = prepare_input($_POST['district']);

	$sql = "insert into trainee(`firstName`,`LastName`,`gender`,`dateOfBirth`,`jobTitle`,`educationLevel`,`mobilePhone`,`email`,`country`,`district`,`regDate`,`UserId`) values('$firstName','$lastName','$gender','$dob','$jobTite','$educationLevel','$phoneNumber','$email','$county','$district', now(),'$userId')";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainee Added Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainee.php'>";
	}else{
    	echo"Error Adding Trainee".mysqli_error($con);
	}
	
}else if(isset($_GET['action']) && $_GET['action'] == "edit"){
	$traineeId = $_GET['edit'];
	$sql = "SELECT * FROM trainee WHERE traineeId = " . $traineeId;
	$que1= mysqli_query($con,$sql);
	$row = mysqli_fetch_array($que1);
	extract($row);
	include('edittrainee.php');

}else if(isset($_POST['editTrainee'])){
	$traineeId = prepare_input($_POST['traineeId']);
	$firstName = prepare_input($_POST['firstName']);
	$lastName = prepare_input($_POST['lastName']);
	$gender = prepare_input($_POST['gender']);
	$dob = prepare_input($_POST['dob']);
	$jobTite = prepare_input($_POST['jobTite']);
	$educationLevel = prepare_input($_POST['educationLevel']);
	$phoneNumber = prepare_input($_POST['phoneNumber']);
	$email = prepare_input($_POST['email']);
	$county = prepare_input($_POST['county']);
	$district = prepare_input($_POST['district']);

	$sql = "update trainee set firstName = '$firstName', LastName = '$lastName', gender = '$gender', dateOfBirth = '$dob', jobTitle = '$jobTite', educationLevel = '$educationLevel', mobilePhone = '$phoneNumber', email = '$email', country = '$county', district = '$district', regDate = NOW(), UserId = '$userId' where traineeId = '$traineeId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainee Updated Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainee.php'>";
	}else{
    	echo"Error Updating Trainee".mysqli_error($con);
	}

}else if(isset($_GET['action']) && $_GET['action'] == "delete"){
	$traineeId = $_GET['delete'];
	$sql = "delete from trainee where TraineeId = '$traineeId'";
	if(mysqli_query($con,$sql)){
    	echo"<script>alert('Trainee Deleted Successfullly')</script>";
    	echo "<meta http-equiv='refresh' content='0;url=trainee.php'>";
	}else{
    	echo"Error Deleting Trainee".mysqli_error($con);
	}
} else{
	?>
	<?php 
	$sql = "SELECT * FROM trainee ORDER BY traineeId";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			
				<input type="text" id="myInput" placeholder="Search for trainees..">
				<a href="trainee.php?action=add" target="fr" class="btn btn-primary">Add Trainee</a>
				
			<div id="printdiv">
				<div><h4 class="text text-info text-center">List of Trainees</h4></div>
			<table border="1" class="table table-bordered" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0">
		<thead>
			<tr><th>#</th><th>First Name</th><th>Last Name</th><th>Gender</th><th>DoB</th><th>Edu. Level</th><th>Phone No.</th><th width="15%">Email</th><th class="no-print">Perform</th></tr>
		</thead>
		<tbody id="myTable">
			<?php
			
			$i=1;
			while($row = mysqli_fetch_array($que1)){
				$traineeId = $row['traineeId'];
				$firstName = $row['firstName'];
				$lastName = $row['LastName'];
				$traineeName = $firstName . " " . $lastName;
				$gender = $row['gender'];
				$dob = $row['dateOfBirth'];
				$jobTitle = $row['jobTitle'];
				$educationLevel = $row['educationLevel'];
				$mobilePhone = $row['mobilePhone'];
				$email = $row['email'];
				$country = $row['country'];
				$district = $row['district'];
				$userId = $row['UserId'];
				?>
				<!-- <table border="1" width="95%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0" id="myTable"> -->
			 
				<tr><td>
				<?php echo $i;?></td><td>
				<?php echo $firstName;?></td><td>
				<?php echo $lastName;?></td><td>
				<?php echo $gender;?></td><td>
				<?php echo $dob;?></td><td>
				<?php echo $educationLevel;?></td><td width="15%">
				<?php echo $mobilePhone;?></td><td>
				<?php echo $email;?></td>
				<td class="no-print">
					<a href="trainee.php?action=edit&edit=<?php echo $traineeId;?>" title="Edit Trainee <?php echo $traineeName;?>">
						<i class="fa fa-pencil-square-o text-dark"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;<a href="trainee.php?action=delete&delete=<?php echo $traineeId;?>" title="Delete Trainee <?php echo $traineeName;?>" onclick="return confirm('Are you sure you want to delete trainee <?php echo $traineeName;?>?');"><i class="fa fa-minus-circle text-danger"></i></a></td>

				</tr>
			
				<?php
				$i += 1;
			}
			?>
			</tbody></table>
			</div>
			<center>
			<button class="printbtn" onclick="printContent('printdiv')">Print</button>
		</center>
			<?php
			// exit;
		}
		else{
			echo'<a href="trainee.php?action=add" target="fr" class="btn btn-primary">Add Trainee</a>';
        	echo'<p class="text text-danger">No Trainees Found</p>';
		}
}
else{
	echo"Cannot Display".mysqli_error($con);
}
}
?>

</center>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
function printContent(el){
		// let nop = document.querySelectorAll('.no-print').style.display = 'none';
		let nop = document.querySelectorAll('.no-print');

		let body = document.getElementById('body');

		for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'none';
		}
		body.style.backgroundImage = "url('white.jpg')";
    var restorepage = document.body.innerHTML;
    var printcontent = document.getElementById(el).innerHTML;
    document.body.innerHTML = printcontent;
    window.print();

    for(let i=0; i< nop.length; i++){
			nop[i].style.display = 'block';
		}
		document.body.innerHTML = restorepage;
		window.location.reload(true);
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>

  <script>

$("#myInput").on("keyup",function(){
        var value = $(this).val().toLowerCase();
        //location.reload(true);

        $("#myTable tr").filter(function(){
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });

      });
</script>
</body>
</html>
