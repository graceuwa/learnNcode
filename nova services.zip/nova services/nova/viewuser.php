<!DOCTYPE html>
<html>
<head>
	<title>View Users</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
include('connection.php');
$sql = "SELECT * FROM users ORDER BY Date";
$que1= mysqli_query($con,$sql);
if($que1){
		$num = mysqli_num_rows($que1);
		if($num){
			?>
			<div id="printdiv">
			<table border="1" width="100%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0"><caption><font color="black"><h3>List of Users</h3></font></caption>
			<tr><th width="7%">FirstName</th><th width="12%">LastName</th><th width="10%">UserName </th><th width="21%">Password</th><th width="10%">Priority</th><th width="10%">Phone</th><th width="10%">NationalId</th><th width="10%">Status</th><th width="10%">User</th></tr></table>
			<?php
			while($row = mysqli_fetch_array($que1)){
				$FirstName = $row['FirstName'];
				$LastName = $row['LastName'];
				$UserName = $row['UserName'];
				$Password = $row['Password'];
				$Priority = $row['Priority'];
				$Phone = $row['Phone'];
				$NationalId = $row['NationalId'];
				$Status = $row['Status'];
				$user = $row['User'];
				?>
				<table border="1" width="100%" bgcolor="#FFCC99" bordercolor="#000000" bordercolordark="#000000" cellpadding="0"><tr><td width="7%">
				<?php echo $FirstName;?></td><td width="12%">
				<?php echo $LastName;?></td><td width="10%">
				<?php echo $UserName;?></td><td width="21%">
				<?php echo $Password;?></td><td width="10%">
				<?php echo $Priority;?></td><td width="10%">
				<?php echo $Phone;?></td><td width="10%">
				<?php echo $NationalId;?></td><td width="10%">
				<?php echo $Status;?></td><td width="10%">
				<?php echo $user;?></td></tr></table>
				<?php
			}
			?>
			</div>
			<center>
			<!-- <button class="printbtn" onclick="printContent('printdiv')">Print</button> -->
		</center>
			<?php
			// exit;
		}
		else{
        	echo"<script>alert(\"Sorry! Trainings not registered!\")</script>";
		}
}
else{
	echo"Cannot Display".mysqli_error($con);
}
?>

<script>
function printContent(el){
	var restorepage = document.body.innerHTML;
	var printcontent = document.getElementById(el).innerHTML;
	document.body.innerHTML = printcontent;
	window.print();
	document.body.innerHTML = restorepage;
}
</script>
<script type="text/javascript">
  function preventBack(){
  window.history.forward();
  }
  setTimeout("preventBack()",0);
  window.onunload=function(){null};
  </script>
</body>
</html>
