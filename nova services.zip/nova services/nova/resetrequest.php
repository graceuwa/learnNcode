<?php
if(isset($_POST["resetpassowrd"])){
	$selector = bin2hex(random_bytes(8));
	$token = random_bytes(32);
	$url = "www.cleartrustconsulting.com/createnewpassword.php?selector=" . $selector . "&validator=" . bin2hex($token);
	$expires = date("U") + 1800;
	include('connection.php');
	$userEmail = $_POST["email"];
	$sql = "DELETE FROM pwdReset WHERE pwdResetEmail = '$userEmail'";
	$que1 = mysqli_query($con,$sql);
	if($que1){
		$hashedToken = password_hash($token, PASSWORD_DEFAULT);
    	$sql1 = "INSERT INTO pwdreset(pwdResetEmail,pwdResetSelector,pwdResetToken,pwdResetExpires) VALUES('$userEmail','$selector','$hashedToken','$expires')";
    	$que2 = mysqli_query($con,$sql1);
    	$to = $userEmail;
    	$subject = 'Reset your password for CTC';
    	$message = '<p>We received a password request. The link to reset your password is below. If you did not make this request, you can ignore this email</p>';
    	$message .= '<p>Here is your password reset link:<br>';
    	$message .= '<a href = "'.$url.'">'.$url.'</a></p>';
    	$headers = "From: CTC <info@cleartrustconsulting.com>\r\n";
    	$headers .= "Reply-To: info@cleartrustconsulting.com\r\n";
    	$headers .= "content-type: text/html\r\n";
    	mail($to,$subject,$message,$headers);
    	header("Location: resetpassowrd.php?reset=success");
	}else{
    	echo"Error in processing request".mysqli_error($con);
	}
	mysqli_close($con);
}
else{
	header("Location: index.php");
}
?>
